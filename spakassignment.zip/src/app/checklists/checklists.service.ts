import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from 'rxjs/operators';
import { Router } from "@angular/router";

import { Checklist} from './checklist.model';

@Injectable({providedIn: 'root'})
export class ChecklistsService {
  private checklists: Checklist[] = [];
  private completedchecklists: Checklist[] = [];
  private cheklistsUpdated = new Subject<Checklist[]>();
  private completedcheklistsUpdated = new Subject<Checklist[]>();
  constructor(private http: HttpClient ,private router: Router) {}

  getChecklists() {
    this.http
      .get<{ message: string; checklists: any }>(
        "http://localhost:3000/api/checklists"
      )
      .pipe(map((checklistData) => {
        return checklistData.checklists.map(checklist => {
          return {
            title: checklist.title,
            status: checklist.status,
            id: checklist._id
          };
        });
      }))
      .subscribe(transformedChecklists=> {
        this.checklists = transformedChecklists;
        this.cheklistsUpdated.next([...this.checklists]);
      });

      return this.checklists;
  }
  getCompletedChecklists() {
    this.http
      .get<{ message: string; checklists: any }>(
        "http://localhost:3000/api/completedchecklists"
      )
      .pipe(map((checklistData) => {
        return checklistData.checklists.map(checklist => {
          return {
            title: checklist.title,
            status: checklist.status,
            id: checklist._id
          };
        });
      }))
      .subscribe(transformedChecklists=> {
        this.checklists = transformedChecklists;
        this.completedcheklistsUpdated.next([...this.checklists]);
      });

      return this.completedchecklists;
  }

  getCompletedChecklistUpdateListener() {
    return this.completedcheklistsUpdated.asObservable();
  }

  getChecklistUpdateListener() {
    return this.cheklistsUpdated.asObservable();
  }

  addChecklist(title: string, status: string) {
    const checklist: Checklist = { id: null, title: title, status: status };
    this.http
      .post<{ message: string, checklistId: string }>("http://localhost:3000/api/checklists", checklist)
      .subscribe(responseData => {
        const id = responseData.checklistId;
        checklist.id = id;
        this.checklists.push(checklist);
        this.cheklistsUpdated.next([...this.checklists]);
      });
  }

  updateChecklist(id: string) {
    let postData: any;
   
      postData = {
        id: id,
        status: 'Completed'
      };
   
    this.http
      .put("http://localhost:3000/api/checklists/" + id, postData)
      .subscribe(responseData => {
       // this.router.navigate(["/create"]);   
        const updatedChecklists = this.checklists.filter(checklist => checklist.id !== id);
        this.checklists = updatedChecklists;
        this.cheklistsUpdated.next([...this.checklists]); 

        const updatedCompletedChecklists = this.completedchecklists.filter(completedchecklist => completedchecklist.id !== id);
        this.completedchecklists = updatedCompletedChecklists;
        this.completedcheklistsUpdated.next([...this.completedchecklists]); 
       
      });
  }
  deleteChecklist(checklistId: string) {
    this.http.delete("http://localhost:3000/api/checklists/" + checklistId)
      .subscribe(() => {
        const updatedChecklists = this.checklists.filter(checklist => checklist.id !== checklistId);
        this.checklists = updatedChecklists;
        this.cheklistsUpdated.next([...this.checklists]);

        const updatedCompletedChecklists = this.completedchecklists.filter(completedchecklist => completedchecklist.id !== checklistId);
        this.completedchecklists = updatedCompletedChecklists;
        this.completedcheklistsUpdated.next([...this.completedchecklists]);
      });
  }
}