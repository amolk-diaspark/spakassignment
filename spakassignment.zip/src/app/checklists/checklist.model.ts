export interface Checklist {
    id: string;
    title: string;
    status: string;
  }