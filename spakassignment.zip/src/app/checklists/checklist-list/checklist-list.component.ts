import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Checklist } from '../checklist.model';
import { ChecklistsService } from "../checklists.service";
declare var $: any;
@Component({
  selector: 'app-checklist-list',
  templateUrl: './checklist-list.component.html',
  styleUrls: ['./checklist-list.component.css']
})
export class ChecklistListComponent implements OnInit {

  
  checklists: Checklist[] = [];
  completedchecklists: Checklist[] = [];
  private checklistsSub: Subscription;
  private completedchecklistsSub: Subscription;

  constructor(public checklistsService: ChecklistsService) {} 

  ngOnInit() {
    //  console.log(this.checklistsService.getChecklists());
    this.checklists = this.checklistsService.getChecklists();
    this.checklistsSub = this.checklistsService.getChecklistUpdateListener()
      .subscribe((checklists: Checklist[]) => {
        this.checklists = checklists;
      });

      this.completedchecklists = this.checklistsService.getCompletedChecklists();
      this.completedchecklistsSub = this.checklistsService.getCompletedChecklistUpdateListener()
        .subscribe((checklists: Checklist[]) => {
          this.completedchecklists = checklists;
        });
      
  }

  onChangeStatus(checkId: string) {
    this.checklistsService.updateChecklist(checkId);
  }
  
  onDelete(checkId: string) {
    this.checklistsService.deleteChecklist(checkId);
  }
  ngOnDestroy() {
    this.checklistsSub.unsubscribe();
    this.completedchecklistsSub.unsubscribe();
  }
  

}