import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ChecklistsService } from "../checklists.service";


@Component({
  selector: 'app-checklist-create',
  templateUrl: './checklist-create.component.html',
  styleUrls: ['./checklist-create.component.css']
})
export class ChecklistCreateComponent  {
    enteredTitle = "";
    enteredContent = "";

    constructor(public checklistsService: ChecklistsService) {}

  
  onAddChecklist(form:NgForm){
    if (form.invalid) {
        return;
      }
      this.checklistsService.addChecklist(form.value.title, 'New');
    form.resetForm();

  }

}