import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { ChecklistListComponent } from "./checklists/checklist-list/checklist-list.component";
import { ChecklistCreateComponent } from "./checklists/checklist-create/checklist-create.component";
import { LoginComponent } from "./auth/login/login.component";
import { SignupComponent } from "./auth/signup/signup.component";
import { AuthGuard } from "./auth/auth.guard";

const routes: Routes = [
  { path: "", component: LoginComponent },
  { path: "create", component: ChecklistListComponent, canActivate: [AuthGuard] },
  { path: "edit/:postId", component: ChecklistListComponent, canActivate: [AuthGuard] },
  { path: "login", component: LoginComponent },
  { path: "signup", component: SignupComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule {}
