import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycom',
  templateUrl: './mycom.component.html',
  styleUrls: ['./mycom.component.css']
})
export class MycomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
